
options(repos = c(CRAN = "https://cloud.r-project.org"))

if (!requireNamespace("tidyestimate", quietly = TRUE)) {
    install.packages("tidyestimate", dependencies = NA, Ncpus = 2)
}
if (!requireNamespace("tidyestimate", quietly = TRUE)) {
    stop("tidyestimate installation failed.")
}

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 4L) {
    stop("Expected input, score output, gene output and session output.")
}

x <- read.delim(
    args[1],
    row.names = 1,
    check.names = FALSE,
    stringsAsFactors = FALSE
)

if (anyDuplicated(rownames(x))) {
    stop("Duplicate gene identifiers in ESTIMATE input.")
}
if (anyDuplicated(colnames(x))) {
    stop("Duplicate sample identifiers in ESTIMATE input.")
}
if (!all(vapply(x, is.numeric, logical(1)))) {
    stop("Non-numeric sample column in ESTIMATE input.")
}

filtered <- tidyestimate::filter_common_genes(
    x,
    id = "hgnc_symbol",
    tidy = FALSE,
    tell_missing = TRUE,
    find_alias = FALSE
)

if (nrow(filtered) < 6000L) {
    stop("Fewer than 6000 common genes matched.")
}

expression_values <- as.matrix(filtered[, -1, drop = FALSE])
if (any(!is.finite(expression_values))) {
    stop("Non-finite retained ESTIMATE expression values.")
}

scores <- tidyestimate::estimate_score(
    filtered,
    is_affymetrix = FALSE
)

required_columns <- c("sample", "stromal", "immune", "estimate")
if (!all(required_columns %in% names(scores))) {
    stop(
        "Unexpected tidyestimate output columns: ",
        paste(names(scores), collapse = ", ")
    )
}

scores <- scores[, required_columns, drop = FALSE]
write.csv(scores, args[2], row.names = FALSE)

write.csv(
    data.frame(Gene = as.character(filtered[[1]])),
    args[3],
    row.names = FALSE
)

capture.output(
    {
        cat(
            "tidyestimate version:",
            as.character(utils::packageVersion("tidyestimate")),
            "\n"
        )
        cat("is_affymetrix: FALSE\n")
        cat("Gene aliases matched: FALSE\n")
        cat("Retained common genes:", nrow(filtered), "\n")
        print(sessionInfo())
    },
    file = args[4]
)

cat("\nESTIMATE completed.\n")
cat("Retained common genes:", nrow(filtered), "\n")
cat("Scored samples:", nrow(scores), "\n")
